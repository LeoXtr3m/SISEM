/**********************************************************
* @file main.c
*
* Proyecto Lab2
* Modulo timer
*
* Este modulo agrupa las funciones de manejo del timer
*
* timer.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 19 Marzo 2021
*
**********************************************************/

#include <msp430.h>
#include <temperatura.h>

static int32_t temperatura;  // variable que almacena la temperatura del while

int main(void)
{
    char* bandera = 0;

	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	initTemp();     // inicializamos el sensor de temperatura

	setFlagTemp(bandera);  // seteo la bandera con 0

	runTemp();   // tomar muestra de la temperatura

    _enable_interrupt();  // se habilitan las interrupciones

	while(1){
        //obtengo estado de las interrupciones habilitado/desabilitado

	    if(*bandera != 0){  // entra si la bandera esta en 1

	        temperatura = getTemp();   // se toma la temperatura y se guarda en la variable temperatura
	        runTemp();   // tomar nueva muestra

	    }

	}
}
