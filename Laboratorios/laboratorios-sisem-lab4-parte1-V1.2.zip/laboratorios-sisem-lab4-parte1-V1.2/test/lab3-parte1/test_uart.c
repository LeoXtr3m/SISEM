/**********************************************************
* @file main.c
*
* Proyecto Lab3
* Modulo UART
*
* Este modulo agrupa las funciones de manejo del timer
*
* test_uart.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 2 de abril 2022
*
**********************************************************/


#include<msp430.h>
#include<string.h>
#include<uart.h>
#include <timer_hw.h>
#include<timer.h>
#include<temperatura.h>
#include"utils.h"
//#include<stdint.h>
#define LED1 (0x0001) //Seleccionamos el pin 1.0

//TIEMPO

unsigned int contar = 0;
unsigned int contadorUART =0;

///TEMPERATURA
static int32_t temperatura;  // variable que almacena la temperatura del while

void main(void)
{
    WDTCTL = WDTPW + WDTHOLD;               // Stop WDT

    unsigned int horasIN =23;
    unsigned int* punthorasIN ;
    punthorasIN =&horasIN  ;

    unsigned int minutosIN =59;
    unsigned int* puntminutosIN  ;
    puntminutosIN =&minutosIN   ;

    unsigned int segundosIN =59;
    unsigned int*  puntsegundosIN;
    puntsegundosIN =&segundosIN  ;

    unsigned int milisegundosIN =750;
    unsigned int* puntmilisegundosIN;
    puntmilisegundosIN =&milisegundosIN  ;


    unsigned int bandera_nuevoTiempo =0;
    unsigned int* bNtiempo;
    bNtiempo =&bandera_nuevoTiempo ;


    ///// t
    tiempo_t t_inicial = {horasIN,minutosIN,segundosIN,milisegundosIN };
    ///// INICIALIZAR MODULO DE TEMPERATURA

    //char* bandera = 0;
    initTemp();     // inicializamos el sensor de temperatura

    static unsigned int banderaTimer =0;
    unsigned int* pt_banderaTimer ;
    pt_banderaTimer =&banderaTimer ;


    //setFlagTemp(pt_banderaTimer);  // seteo la bandera con 0

    runTemp();   // inicializacion del modulo de temepratura

    ///// INICIALIZAR MODULO DE TIMER
    unsigned int tikss =8;
    unsigned int* Stiks;
    Stiks=&tikss;

    setFlagTimer(pt_banderaTimer, tikss);

    tiempo_t tiempo;
    P1DIR = 0;  // Pongo todos los pines como entradas
    P1DIR |= LED1; // Ponemos el pin 1.0 como salida

    config_timer_crystal(); //inicializamos el timer hardware crystal, se agrega en timer_hw.h

    //config_timer_VLO();   //inicializamos el timer hardware  VLO, se agrega en timer_hw.h

    vInitTimerA(); // se inicializa el timer A

    //inicializamos nuestro timer para ver problema de datos compartidos
    set_time(t_inicial); // se setea el tiempo
    get_time(&tiempo);  // se toma el tiempo


    ////// INICIALIZAMOS EL MODULO UART

    //inicializamos la bandera EOL
    static unsigned int EOL=0;
    unsigned int* pt_EOL;
    pt_EOL=&EOL;

    //inicializamos UART
    uart_init(pt_EOL);






    __enable_interrupt();

    while (1){

        // se activa de acuerdo a la configuracion de milisegundos configurados en timer_hw.c
         if (banderaTimer == 1){
             banderaTimer = 0;   // se resetea la bandera en 0
            //se ponde
             contar++;  // variable para contar cuantas veces se ingreso
             temperatura = getTemp();   // se toma la temperatura y se guarda en la variable temperatura
             runTemp();   // se configura nuevamente la temperatura
             ///
             get_time(&tiempo); // se toma el tiempo actual y se guarda en la variable tiempo
             add_temp(temperatura, tiempo.hh, tiempo.mm, tiempo.ss);    // A�ade el valor de la temperatura al buffer
             copiar_temp(&buffer_ext[0]);
             transmitir_TX(&buffer_ext[0]);             //mandamos los datos

        }

        //UART Si llega informacion se ejecuta
        if (EOL == 1){
            EOL = 0;
            contadorUART++;
            evaluar_comandos(Stiks,tikss,temperatura, punthorasIN, puntminutosIN, puntsegundosIN, puntmilisegundosIN,bNtiempo);
            if(bandera_nuevoTiempo ==1){  // Se setea el tiempo si la bandera de setearse el tiempo se presenta
                bandera_nuevoTiempo =0;
                t_inicial.hh = horasIN;
                t_inicial.mm = minutosIN;
                t_inicial.ss = segundosIN;
                set_time(t_inicial); // se setea el tiempo
            }
            setFlagTimer(pt_banderaTimer, tikss);  // se setea nuevamente los tiks por si hubo un cambio
            copiar_ext(&buffer_ext[0]);
            transmitir_TX(&buffer_ext[0]);             //mandamos los datos


         }

    }
}
