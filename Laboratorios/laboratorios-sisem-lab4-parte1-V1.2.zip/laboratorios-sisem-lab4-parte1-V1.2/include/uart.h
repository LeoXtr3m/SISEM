/**********************************************************
* @file main.c
*
* Proyecto Lab3
* Modulo UART
*
* Este modulo agrupa las funciones de manejo del timer
*
* test_uart.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 2 de abril 2022
*
**********************************************************/


#ifndef INCLUDE_UART_H_
#define INCLUDE_UART_H_

//#include<stdint.h>

#define BUFF 32   // tama�o de los buffers
static char buffer_TX[BUFF];   // se les pasa el tama�o a todos por igual
static char buffer_RX[BUFF];
static char buffer_ext[BUFF];

static char buffer_temp[BUFF];

/**
 * @brief funcion que inicializa UART
 */

void uart_init(unsigned int* pt_fin);

/**
 * @brief funcion que para transmitir. Copia en el buffer de transmicion el mensaje a enviar y habilita interrupcion de registro vacio.
 * @param char* mensaje: puntero a el mensaje a transmitir.
 *
 */

void transmitir_TX(char* mensaje);

/**
 * @brief funcion que copia el buffer de recepcion a buffer externo.
 * @param char* buff_ext: puntero al buffer externo.
 */

void copiar_ext(char* buff_ext);


 ////////////////////////////////////////////////////////


/**
 * @brief funcion que a�ade temperatura y la hora actual al buffer temp
 * @param int* temp: puntero con la temperatura actual.
 * @param int* horas: puntero con la hora actual.
 * @param int* minutos: puntero con la minutos actuales.
 * @param int* segundos: puntero con la segundos actuales.
 *
 */

void add_temp(int* temp,int* horas,int* minutos,int* segundos );

/**
 * @brief funcion que copia el buffer de temperatura
 * @param char* buff_temp: puntero al buffer temperatura.
 */

void copiar_temp(char* buff_temp);    //Copia la temperatura al buffer


/**
 * @brief funcion que evalua los parametros que entran por consola a la UART
 * @param int* tiksXX: puntero de salida de los tiks ingresados en WP XX.
 * @param int* tiks_actual: puntero de entrada de los tiks actuales .
 * @param int* temp_actual: puntero de entrada de la temeperatura actual.
 * @param int* horass: puntero de salida de la hora ingresada que se ingresa en Buffer_RX.
 * @param int* minutoss: puntero de salida de los minutos que se ingresan en Buffer_RX.
 * @param int* segundoss: puntero de salida de los segundos que se ingresan en Buffer_RX.
 * @param int* milisegundoss: puntero de salida de los milisegundos que se ingresan en Buffer_RX.
 * @param unsigned int* flag_newTime: puntero de salida del flag si se cambio el tiempo con WH XX:XX:XX.
 */


void evaluar_comandos(int* tiksXX, int* tiks_actual, int* temp_actual,int* horass,int* minutoss,int* segundoss, int* milisegundoss, unsigned int* flag_newTime);











#endif /* INCLUDE_UART_H_ */



