/**********************************************************
* @file main.c
*
* Proyecto Lab3
* Modulo UART
*
* Este modulo agrupa las funciones de manejo del timer
*
* test_uart.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 2 de abril 2022
*
**********************************************************/

#ifndef INCLUDE_FUNCIONENCOLADO_H_
#define INCLUDE_FUNCIONENCOLADO_H_

/**
 * @brief Se declara la funcion que envia la informacion para mostrar en pantalla de acuerdo a los tiks
 * @param tiempo_t *t: variable puntero que extrae el tiempo
 * @param int  *temperatura: variable que extrae la temperatura
 * @param int temp_add: variable que lleva la temperatura
 */

void funcionEncoladoTEMP(tiempo_t *t, int  *temperatura, int temp_add);


/**
 * @brief Se declara la funcion que envia la informacion de la UART
 * @param int *Tiks_XX: variable puntero que extrae los tiks que se asignan en la uart
 * @param int* tiks_Actual: variable que lleva los tiks actuales
 * @param int* temp_Actual: variable que lleva la temperatura actual
 */
void funcionEncoladoUART(int *Tiks_XX, int* tiks_Actual, int* temp_Actual);

#endif /* INCLUDE_FUNCIONENCOLADO_H_ */
