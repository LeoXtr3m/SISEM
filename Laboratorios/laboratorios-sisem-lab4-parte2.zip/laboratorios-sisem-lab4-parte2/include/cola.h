/**********************************************************
* @file main.c
*
* Proyecto Lab4
* Modulo  Planificaci�n por encolado de funciones
*
* Este modulo agrupa las funciones de manejo del timer
*
* cola.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 22 de abril 2022
*
**********************************************************/

#ifndef INCLUDE_COLA_H_
#define INCLUDE_COLA_H_

#define TAM_MAX 6

/**
 * @brief Se declara la estructura de la cola y se le asigna el nombre de nCola a la estructura
 * @param int *list[TAM_MAX]: arreglo de los valores que tendra la estructura, se le define su dimencion y es un puntero a funciones
 * @param int tam: variable que nos indicara que tama�o tiene la lista mientras esta se llena;
 */
typedef struct{
    int *list[TAM_MAX];  //puntero a funciones
    int tam;
}nCola;


/**
 * @brief Se asigna el nombre de las funciones int como punteros *pf_t como en el archivo punteros_a_funciones_v2
 */
typedef int (*pf_t)();

typedef void (*pf_v)();

/**
 * @brief funcion de inicializacion de la cola
 */

nCola inicializaCola();


/**
 * @brief funcion que verifica si la cola esta vacia
 * @param nCola cola: pasa la estructura de la cola
 */
int estaVacia(nCola cola);


/**
 * @brief funcion que verifica si la cola esta llena
 * @param nCola cola: pasa la estructura de la cola
 */
int estaLlena(nCola cola);


/**
 * @brief funcion que pone un valor en la cola
 * @param nCola *cola: pasa la estructura de la cola como puntero
 * @param int elem: es el valor que se trae desde el main para ingresar a la cola
 */
int ponerEnCola(nCola *cola, int elem);


/**
 * @brief funcion que extrae el primer valor de la cola
 * @param nCola *cola: pasa la estructura de la cola como punterov
 */
int extraerDeCola(nCola *cola);


#endif /* INCLUDE_COLA_H_ */
