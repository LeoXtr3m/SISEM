/*
 * temperatura.c
 *
 *  Created on: 
 *      Author:
 */



/***********************
 * Calcular temperatura usando float
 ***********************/
float getTemp_1(int datoTemp)
{
    return (datoTemp * 0.413 - 277.75);
}

/***********************
 * Multiplicaci�n binaria de a y b
 ***********************/
long binaryMultiplication(int a, long b)
{
    long prod;

    prod = 0;
    while (a != 0)
    {
        if ((a & 0x01) != 0) // Verificar el bit menos significativo de a
            prod = prod + b; // si es 1, acumular b
        b = b << 1; // left shift. Multiplicar b por 2
        a = a >> 1; // right shift. Dividir a entre 2
    }
    return prod;
}

/***********************
 * Calcular temperatura int y multliplicaci�n
 ***********************/
float getTemp_2(int datoTemp)
{
    volatile long dt;
    volatile float retValue;

    dt = datoTemp * (long)413 - 277750;

    retValue = (float) (dt / 1000.0);
    return retValue;
}

/***********************
 * Calcular temperatura usando int y multiplicacion binaria
 ***********************/
float getTemp_3(int datoTemp)
{
    volatile long dt;
    volatile float retValue;

    dt = binaryMultiplication(datoTemp, 413) - 277750;
    retValue = (float) (dt / 1000.0);
    return retValue;
}
