/**********************************************************
* @file main.c
*
* Proyecto Lab4
* Modulo  Planificaci�n por encolado de funciones
*
* Este modulo agrupa las funciones de manejo del timer
*
* cola.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 22 de abril 2022
*
**********************************************************/

#include <cola.h>
#include <stdio.h>

int valor=0;



/****************************************************************************************************
 * funcion de inicializacion de la cola
****************************************************************************************************/
nCola inicializaCola(){  //inicializa la cola con nombre cola, tama�o 0
    nCola cola;
    cola.tam=0;
    return cola;
}



/****************************************************************************************************
 * funcion que verifica si la cola esta vacia
 * nCola cola: pasa la estructura de la cola
****************************************************************************************************/
int estaVacia(nCola cola){   //funcion para evaluar si esta vacia
    if(cola.tam==0){
        return 1;
    }else{
    return 0;
    }
}


/****************************************************************************************************
 * funcion que verifica si la cola esta llena
 * nCola cola: pasa la estructura de la cola
****************************************************************************************************/
int estaLlena(nCola cola){   //funcion para evaluar si esta llena
    if(cola.tam==TAM_MAX-1){
        return 1;
    }else{
    return 0;
    }
}


/****************************************************************************************************
 * funcion que pone un valor en la cola
 * nCola *cola: pasa la estructura de la cola como puntero
 * int elem: es el valor que se trae desde el main para ingresar a la cola
****************************************************************************************************/
int ponerEnCola(nCola *cola,int elem){  //funcion para poner valor en el ultimo valor de la cola
       cola->list[cola->tam]=elem;
       cola->tam=cola->tam+1;
}


/****************************************************************************************************
 * funcion que elimina el valor de la cola (no se llama desde main)
 * nCola *cola: pasa la estructura de la cola como punterov
 * int p: es el valor de inicializacion de la cola (0) o de donde se tomara el digito a eliminar
****************************************************************************************************/
void elimina(nCola *cola,int p){  //funcion para eliminar el primer valor de la cola
    int i;
    for(i=p;i<=cola->tam-1;i++){  //recorre la lista un valor copiando y pegando

        if(i==cola->tam){  // si es el ultimo valor lo pone en null
            cola->list[i]=NULL;
        }
        else{
            cola->list[i]=cola->list[i+1]; // recorre el valor a uno anterior (sobreescribe en valor anterior)
        }
    }//p=posicion
    cola->tam=cola->tam-1;
}

/****************************************************************************************************
 * funcion que extrae el primer valor de la cola
 * nCola *cola: pasa la estructura de la cola como punterov
****************************************************************************************************/
int extraerDeCola(nCola *cola){
     int elem;
     elem=cola->list[0];
     elimina(cola,0);
     return elem; // se manda el valor extraido


}





