/**********************************************************
* @file main.c
*
* Proyecto Lab3
* Modulo UART
*
* Este modulo agrupa las funciones de manejo del timer
*
* test_uart.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 2 de abril 2022
*
**********************************************************/

#include<msp430.h>
#include<string.h>
#include<uart.h>
#include <timer_hw.h>
#include<timer.h>
#include<temperatura.h>
#include"utils.h"
#include <cola.h>
#include <funcionEncolado.h>


unsigned int tiks_extraidos;

tiempo_t tiempo_obtenido;  //Variable del tiempo



/**
 * Se declara la funcion que envia la informacion para mostrar en pantalla de acuerdo a los tiks
 * tiempo_t *t: variable puntero que extrae el tiempo
 * int  *temperatura: variable que extrae la temperatura
 * int temp_add: variable que lleva la temperatura
 */

void funcionEncoladoTEMP(tiempo_t *t, int  *temperatura, int temp_add){
    *temperatura = getTemp();   // se toma la temperatura y se guarda en la variable temperatura
    runTemp();   // se configura nuevamente la temperatura

    get_time(&tiempo_obtenido); // se toma el tiempo actual y se guarda en la variable tiempo
    *t = tiempo_obtenido;
    add_temp(temp_add);    // A�ade el valor de la temperatura al buffer

    copiar_temp(&buffer_temp[0]);
    transmitir_TX(&buffer_temp[0]);             //mandamos los datos
}



/**
 * Se declara la funcion que envia la informacion de la UART
 * int *Tiks_XX: variable puntero que extrae los tiks que se asignan en la uart
 * int* tiks_Actual: variable que lleva los tiks actuales
 * int* temp_Actual: variable que lleva la temperatura actual
 */
void funcionEncoladoUART(int *Tiks_XX, int* tiks_Actual, int* temp_Actual){

    evaluar_comandos(&tiks_extraidos,tiks_Actual,temp_Actual);
    *Tiks_XX = tiks_extraidos;
    copiar_ext(&buffer_ext[0]);
    transmitir_TX(&buffer_ext[0]);
}

