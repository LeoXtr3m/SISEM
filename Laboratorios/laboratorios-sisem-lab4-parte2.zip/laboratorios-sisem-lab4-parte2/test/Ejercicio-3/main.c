#include <stdio.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <moduloCola.h>
#include <assert.h>   //libreria assert para verificar que se cumpla la sentencia

int valorColaVacia = 0;
int valorColaLlena = 0;
int valorPonerEnCola = 0;
int valorExtraido = 0;


//se nombra la cola a crear
nCola2 cola;


int main(){

    //Se inicializa la cola
    cola=inicializaCola2();

    // se consulta si la cola esta vacia
    valorColaVacia = estaVacia2(cola);

    // se consulta si la cola esta llena
    valorColaLlena = estaLlena2(cola);

    // se ponen los valores en la cola (en el ultimo espacio libre
    //assert(estaLlena(cola) == 0);// si la cola no esta llena entra
    valorPonerEnCola = ponerEnCola2(&cola,2);
    //assert(estaLlena(cola) == 0);
    valorPonerEnCola = ponerEnCola2(&cola,4);
    //assert(estaLlena(cola) == 0);
    valorPonerEnCola = ponerEnCola2(&cola,6);
    //assert(estaLlena(cola) == 0);
    valorPonerEnCola = ponerEnCola2(&cola,3);
    //assert(estaLlena(cola) == 0);
    valorPonerEnCola = ponerEnCola2(&cola,4);

    // se elimina el ultimo valor de la cola con cada funcion y se extra el primer valor
    //assert(estaVacia(cola) == 0);
    valorExtraido  = quitarDeCola2(&cola);
    //assert(estaVacia(cola) == 0);
    valorExtraido  = quitarDeCola2(&cola);
    //assert(estaVacia(cola) == 0);
    valorExtraido  = quitarDeCola2(&cola);

    return 0;
}







