/**********************************************************
* @file main.c
*
* Proyecto Lab3
* Modulo UART
*
* Este modulo agrupa las funciones de manejo del timer
*
* test_uart.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 2 de abril 2022
*
**********************************************************/


#include<msp430.h>
#include<string.h>
#include<uart.h>
#include <timer_hw.h>
#include<timer.h>
#include<temperatura.h>
#include"utils.h"
#include <cola.h>
//#include<stdint.h>
#define LED1 (0x0001) //Seleccionamos el pin 1.0



/********************************************
 *VARIABLE QUE ALMACENA LA TEMPERATURA      *
 ********************************************/
static int32_t temperatura;  // variable que almacena la temperatura del while



void main(void)

{
    WDTCTL = WDTPW + WDTHOLD;               // Stop WDT

    /********************************************
     *        SE INICIALIZA EL TIEMPO           *
     ********************************************/
    tiempo_t t_inicial = {23,59,59,750 };


    /********************************************
     *   SE INICIALIZA EL MODULO TEMPETARUTA    *
     ********************************************/

    //char* bandera = 0;
    initTemp();     // inicializamos el sensor de temperatura

    //Bandera del sensor de temperatura ADC
    static unsigned int banderaTemp =0;
    unsigned int* pt_banderaTemp;
    pt_banderaTemp =&banderaTemp ;

    setFlagTemp(pt_banderaTemp);  // seteo la bandera con 0

    runTemp();   // inicializacion del modulo de temepratura

    /********************************************
     *       INICIALIZAR MODULO DE TIMER        *
     ********************************************/
    unsigned int tikss =8;
    unsigned int* Stiks;
    Stiks=&tikss;

    ////bandera del timer
    static unsigned int banderaTimer =0;
    unsigned int* pt_banderaTimer;
    pt_banderaTimer = &banderaTimer ;

    setFlagTimer(pt_banderaTimer, tikss);

    tiempo_t tiempo;  //Variable del tiempo
    P1DIR = 0;  // Pongo todos los pines como entradas
    P1DIR |= LED1; // Ponemos el pin 1.0 como salida

    config_timer_crystal(); //inicializamos el timer hardware crystal, se agrega en timer_hw.h

    //config_timer_VLO();   //inicializamos el timer hardware  VLO, se agrega en timer_hw.h

    vInitTimerA(); // se inicializa el timer A

    //inicializamos nuestro timer para ver problema de datos compartidos
    set_time(t_inicial); // se setea el tiempo
    get_time(&tiempo);  // se toma el tiempo


    /********************************************
     *       INICIALIZAMOS EL MODULO UART       *
     ********************************************/

    //inicializamos la bandera EOL
    static unsigned int EOL=0;
    unsigned int* pt_EOL;
    pt_EOL=&EOL;

    //inicializamos UART
    uart_init(pt_EOL);



    /********************************************
     *       INICIALIZAMOS EL PROGRAMA          *
     ********************************************/

    __enable_interrupt();

    while (1){

        //TICKs  -- se activa de acuerdo a la configuracion de milisegundos configurados en timer_hw.c
         if (banderaTimer == 1){   //Ticks completos
             banderaTimer = 0;   // se resetea la bandera en 0
             temperatura = getTemp();   // se toma la temperatura y se guarda en la variable temperatura
             runTemp();   // se configura nuevamente la temperatura
             get_time(&tiempo); // se toma el tiempo actual y se guarda en la variable tiempo
             add_temp(temperatura);    // Añade el valor de la temperatura al buffer
             copiar_temp(&buffer_temp[0]);
             transmitir_TX(&buffer_temp[0]);             //mandamos los datos
        }


        //UART Si llega informacion se ejecuta
        if (EOL == 1){
            EOL = 0;
            evaluar_comandos(Stiks,tikss,temperatura);
            copiar_ext(&buffer_ext[0]);
            transmitir_TX(&buffer_ext[0]);             //mandamos los datos
         }

        if((banderaTimer == 0)&&(EOL == 0)){
            LPM3;
        }
    }
}
