/**********************************************************
* @file main.c
*
* Proyecto Lab4
* Modulo  Planificaci�n por encolado de funciones
*
* Este modulo agrupa las funciones de manejo del timer
*
* cola.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 22 de abril 2022
*
**********************************************************/


#include <msp430.h> 
#include <stdio.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <cola.h>
#include <assert.h>   //libreria assert para verificar que se cumpla la sentencia
#define FUN_MAX 6



//se nombra la cola a crear
nCola cola;

//se nombra el puntero a funciones "int"
pf_t f_int[FUN_MAX];

pf_v f_void[FUN_MAX];
//variables para probar
pf_v funExtraida;

int ci = 0;
int cj = 0;
int cz = 0;

//funciones para probar el funcionamiento
void fun1cola(void){
    ci++;
}
void fun2cola(void){
    cj++;
}
void fun3cola(void){
    cz++;
}

//variables para el programa de testeo
int agregar = 1;
int quitar = 0;
int dato = 5;
int colaLlena =0;
int colaVacia =0;
int valorExtraido;

int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
    //Se inicializa la cola
    cola=inicializaCola();

    //funciones a punteros,
    f_void[0] = fun1cola;
    f_void[1] = fun2cola;
    f_void[2] = fun3cola;
    f_void[3] = fun1cola;
    f_void[4] = fun2cola;

    __enable_interrupt();

    while (1){


        if(agregar==1){
            if(estaLlena(cola)!=1){ //se la cola no esta llena, entra
                //assert(funcion[1](cola) == 0); //nos aseguramos que la cola no este llena
                ponerEnCola(&cola,f_void[0]); // se agrega el dato a la cola
                colaLlena =0;
            }
            else{
                colaLlena =1;
                quitar=1;
                agregar =0;
            }
        }
        else if(quitar == 1){
            if(estaVacia(cola)!=1){ //si la cola no esta vacia, entra
                //assert(funcion[0](cola) == 0); //nos aseguramos que la cola no este vacia
                funExtraida= extraerDeCola(&cola);  // se extrae el valor de la posicion 1
                funExtraida();  //se ejecuta la funcion de ejemplo fun1cola
                colaVacia =0;
            }
            else{
                colaVacia =1;
                agregar=1;
                quitar=0;
            }
        }

    }


}


//estaVacia(cola);   //verifica si la cola esta vacia
//estaLlena(cola);   //verifica si la cola esta llena
//ponerEnCola(&cola,3); // se pone un valor en la cola
//extraerDeCola(&cola);  // se extrae el valor de la posicion 1



//funcion[0](cola);   //verifica si la cola esta vacia
//funcion[1](cola);   //verifica si la cola esta llena
//funcion[2](&cola,3); // se pone un valor en la cola
//funcion[3](&cola);  // se extrae el valor de la posicion 1
