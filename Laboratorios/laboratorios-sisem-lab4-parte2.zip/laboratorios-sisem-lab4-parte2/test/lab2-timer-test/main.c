/**********************************************************
* @file main.c
*
* Proyecto Lab2
* Modulo timer
*
* Este modulo agrupa las funciones de manejo del timer
*
* timer.c
* @version 1.0
* @author   Leoncio Rios, Jesus Calixto
* Version inicial
* @date 19 Marzo 2021
*
**********************************************************/

#include <msp430.h>
#include <timer_hw.h>
#include <timer.h>
#define LED1 (0x0001) //Seleccionamos el pin 1.0

tiempo_t t_inicial = {23,59,59,750};


void main(void){


    WDTCTL = WDTPW | WDTHOLD;   // Desactivamos watchdog timer
    tiempo_t tiempo;
    P1DIR = 0;  // Pongo todos los pines como entradas
    P1DIR |= LED1; // Ponemos el pin 1.0 como salida

    //config_timer_crystal(); //inicializamos el timer hardware crystal, se agrega en timer_hw.h

    config_timer_VLO();   //inicializamos el timer hardware  VLO, se agrega en timer_hw.h

    vInitTimerA(); // se inicializa el timer A

    //inicializamos nuestro timer para ver problema de datos compartidos
    set_time(t_inicial); // se setea el tiempo
    get_time(&tiempo);  // se toma el tiempo


    _enable_interrupt();  // se habilitan las interrupciones

    while(1){   //bucle infinito

        //obtengo estado de las interrupciones habilitado/desabilitado
        short s = _get_interrupt_state();
        _disable_interrupt(); // se desabilitan las interrupciones
        get_time(&tiempo);   // se toma el tiempo y se guarda en la variable tiempo
        _set_interrupt_state(s); // se habilitan las interrupciones
    }

}
