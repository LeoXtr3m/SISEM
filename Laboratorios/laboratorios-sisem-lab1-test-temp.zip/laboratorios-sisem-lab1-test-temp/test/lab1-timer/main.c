/**********************************************************
* @file main.c
*
* Proyecto Lab1
* Modulo Timer
*
* Contiene el main que controla el timer.
*
* main.c
* @version 1.0
* @author  Leoncio Rios, Jesus Calixto
* Version inicial
* @date 12 Marzo 2022
*
**********************************************************/
#include <msp430.h>
#include <timer.h>

int main(void)
{
    volatile int i;
    tiempo_t t_local;

    WDTCTL = WDTPW | WDTHOLD; // stop watchdog timer

    set_time(t_inicial);

    get_time(&t1);

    inc_time();
    inc_time();
    inc_time();

    get_time(&t2);
    get_time(&t_local);

    return 0;
}
