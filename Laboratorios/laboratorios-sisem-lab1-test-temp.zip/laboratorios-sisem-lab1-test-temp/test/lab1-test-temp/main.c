#include <msp430.h>
#include <temperature.h>

/**
 * main.c
 */

int main(void)
{
    volatile float f_temp=0.0;

    WDTCTL = WDTPW | WDTHOLD; // stop watchdog timer

    // Version 1: Con float
     f_temp = getTemp_1(800);

    // Version 2: Con int
//    f_temp = getTemp_2(800);

    // Version 3: Con int y multiplicacion binaria
//     f_temp = getTemp_3(800);

    return 0;
}
