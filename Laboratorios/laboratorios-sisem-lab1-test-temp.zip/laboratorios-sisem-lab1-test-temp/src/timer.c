/**********************************************************
* @file timer.c
*
* Proyecto Lab1
* Modulo timer
*
* Este modulo agrupa las funciones de manejo del timer
*
* timer.c
* @version 1.0
* @author  Leoncio Rios, Jesus Calixto
* 
* @date 12 Marzo 2022
*
**********************************************************/

#include <timer.h>

//----------------------------------------------------------
// Variable privada que mantiene el valor actual de la hora
//----------------------------------------------------------
static tiempo_t t_current;

//----------------------------------------------------------
// Variable globales
//----------------------------------------------------------
tiempo_t t_inicial = {23, 59, 59, 500};
tiempo_t t1;
tiempo_t t2;

//----------------------------------------------------------
//
//----------------------------------------------------------
void get_time(tiempo_t* t)
{
    t->hh = t_current.hh;
    t->mm = t_current.mm;
    t->ss = t_current.ss;
    t->mi = t_current.mi;
    return;
}


//----------------------------------------------------------
// Incrementa en 250 milisegundos a la hora actual, manteniendo la consistencia de la hora resultante
//----------------------------------------------------------
void inc_time(void)
{
    t_current.mi += 250;
    if (t_current.mi == 1000)
    {
        t_current.mi = 0;
    }

    if (t_current.mi == 0)
    {
        if (t_current.ss == 59)
        {
            t_current.ss = 0;

            if (t_current.mm == 59)
                t_current.mm = 0;
            else
                t_current.mm += 1;

            if (t_current.mm == 0)
                if (t_current.hh == 23)
                    t_current.hh = 0;
                else
                    t_current.hh += 1;
        }
        else
            t_current.ss += 1;
    }
}

//----------------------------------------------------------
//
//----------------------------------------------------------
void set_time(tiempo_t t)
{
    t_current.hh = t.hh;
    t_current.mm = t.mm;
    t_current.ss = t.ss;
    t_current.mi = t.mi;
    return;
}
