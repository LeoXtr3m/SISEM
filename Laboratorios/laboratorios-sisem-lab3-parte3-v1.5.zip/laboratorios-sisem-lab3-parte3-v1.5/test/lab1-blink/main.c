#include <msp430.h> 
#define LED1 (0x0001)


/**
 * main.c
 */
int main(void)
{
    volatile unsigned int i;
    WDTCTL = WDTPW + WDTHOLD;
    P1DIR |= LED1;
    while(1)
    {
        P1OUT ^= LED1;
        for (i=10000; i>0; i--);
    }
}
