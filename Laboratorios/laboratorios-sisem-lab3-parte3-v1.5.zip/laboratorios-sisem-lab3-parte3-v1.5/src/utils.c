/*
 * funciones_auxiliares.c
 *
 *  Created on: Mar 21, 2019
 *      Author: jschandy
 */

/**
 * Ansi C "itoa" based on Kernighan & Ritchie's "Ansi C":
 */

#include <utils.h>
//#include "timer.h"

#define BASE 10

void strreverse(char* begin, char* end) {

    char aux;
    while(end>begin)
        aux=*end, *end--=*begin, *begin++=aux;
}

void itoa(int value, char* str) {
    static char num[] = "0123456789abcdefghijklmnopqrstuvwxyz";
    char* wstr=str;
    int sign;
    // Take care of sign
    if ((sign=value) < 0) value = -value;
    // Conversion. Number is reversed.
    do *wstr++ = num[value%BASE]; while(value/=BASE);
    if(sign<0) *wstr++='-';
    //*wstr='\0';
    // Reverse string
    strreverse(str,wstr-1);
}





void intTOchar(int value, char* str1, char* str2) {

    int i=  0;
    int ii =0;
    int cifras[1];
    int cifras2[1];
    char* char1=str1;
    char* char2=str2;

    if(value==0){
        *char1 = 0 + '0' ;
        *char2 = 0 + '0' ;
    }
    else if(value>0 && value<10){
        *char1 =  0 + '0' ;
        *char2 = (value%10) + '0';

    }
    else if(value>=10){
        i = 0;
        while(value>0){
            cifras[i] = value%10;   //obtengo el ultimo digito sin decimal
            value =value/10;   // divido entre 10 para que me de un decimal y elimarlo
            i++;    // sumo 1 para guardar el siguiente numero
        }
        ii =0;
        for(value = i-1 ; value >=0; value--){
            cifras2[ii] = cifras[value];      // se guarda del valor mayor del arreglo al menor
            ii++;
        }

        *char1 =  cifras2[0] + '0' ;
        *char2 =  cifras2[1] + '0' ;

    }



}





