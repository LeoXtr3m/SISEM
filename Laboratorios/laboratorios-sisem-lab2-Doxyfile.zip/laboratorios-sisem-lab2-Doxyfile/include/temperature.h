/*
 * temperature.h
 *
 *  Created on:
 *  Author:
 */

#ifndef TEMPERATURE_H_
#define TEMPERATURE_H_

/***********************
 * Calcular temperatura usando float
 ***********************/
float getTemp_1(int datoTemp);

/***********************
 * Calcular temperatura int y multliplicaci�n
 ***********************/
float getTemp_2(int datoTemp);

/***********************
 * Calcular temperatura usando int y multiplicacion binaria
 ***********************/
float getTemp_3(int datoTemp);

#endif /* TEMPERATURE_H_ */
