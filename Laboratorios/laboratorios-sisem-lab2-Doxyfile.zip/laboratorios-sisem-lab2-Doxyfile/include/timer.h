/**
 * @file timer.h
 * @brief Interfaz de timer
 *
 * Proyecto Lab1
 * Modulo Timer
 * Este modulo agrupa las funciones de manejo del timer
 *
 * timer.h
 * Expone funciones de timer, como inicializacion, incremento de hora y obtencion de hora actual
 *
* @author  Leoncio Rios, Jesus Calixto
* @version 1.0
* @date 12 Marzo 2022
 */
#include <stdint.h>
#ifndef TIMER_H_
#define TIMER_H_

/**********************************************************
 * Estructura para almacenar la hora:
 *   hh: hora (0..23)
 *   mm: minuto (0..60)
 *   ss: segundo (0..60)
 *   mi: milisegundo (0..999)
 **********************************************************/
typedef struct
{
    uint8_t hh;
    uint8_t mm;
    uint8_t ss;
    uint16_t mi;
} tiempo_t;
 

/**********************************************************
 * Funciones del modulo
 **********************************************************/

/**
 * Obtener hora actual
 * @param tiempo_t *t: Puntero a una estructura tiempo_t en donde se almcenara la hora obtenida
 * @return void
 */
void get_time(tiempo_t *t);

/**
 * Incrementar hora. 250 milisegundos a la hora actual. No devuelve ni recibe datos
 * @param void
 * @return void
 */
void inc_time(int ms);

/**
 * Asigna un valor a la hora actual
 * @param tiempo_t t: Estructura de tipo tiempo_t en donde se recibe el valor de la hora a asignar
 * @return void
 */
void set_time(tiempo_t t);

#endif /* TIMER_H_ */
